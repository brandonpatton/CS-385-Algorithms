#!/bin/bash
appletviewer -J-Djava.security.policy=appletpolicy index.shtml
