To execute this program, open a terminal and run
   bash runme.sh
from inside the folder.
If it does not work, verify you have Java installed.
